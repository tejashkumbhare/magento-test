var config = {
    deps: [
        "Magento_Theme/js/custom"
    ],
    map: {
        '*': {
            'slick' :  'Magento_Theme/js/slick'
        }
    },
    "shim": {
        "slick": ['jquery']
    },
};
